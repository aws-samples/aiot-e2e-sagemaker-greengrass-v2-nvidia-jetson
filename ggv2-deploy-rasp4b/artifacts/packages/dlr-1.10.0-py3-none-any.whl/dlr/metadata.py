NAME = ['DLRModel']

VERSION = "1.10.0"