PYTHON_EXTENSIONS_PATHS = [
    '/home/daekeun/opencv/build/lib/'
] + PYTHON_EXTENSIONS_PATHS
