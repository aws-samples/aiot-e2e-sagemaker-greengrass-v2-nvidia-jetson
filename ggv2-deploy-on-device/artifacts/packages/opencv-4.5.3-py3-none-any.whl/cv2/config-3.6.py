PYTHON_EXTENSIONS_PATHS = [
    '/home/daekeun/opencv/build/lib/python3'
] + PYTHON_EXTENSIONS_PATHS
