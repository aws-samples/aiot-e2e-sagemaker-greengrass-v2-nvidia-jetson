import os

BINARIES_PATHS = [
    '/home/daekeun/opencv/build/lib'
] + BINARIES_PATHS
